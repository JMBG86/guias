from django.contrib import admin
from .models import Clinica, Guia

admin.site.register(Clinica)
admin.site.register(Guia)